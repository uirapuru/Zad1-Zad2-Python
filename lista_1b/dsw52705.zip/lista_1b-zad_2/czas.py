def sekundy_na_minuty(sekundy):
    return sekundy / 60

def minuty_na_godziny(minuty):
    return minuty / 60

def godziny_na_dni(godziny):
    return godziny / 24

def dni_na_godziny(dni):
    return dni * 24

def godziny_na_minuty(godziny):
    return godziny * 60

def minuty_na_sekundy(minuty):
    return minuty * 60
